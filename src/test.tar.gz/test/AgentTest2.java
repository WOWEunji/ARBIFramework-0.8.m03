package test;

import kr.ac.uos.ai.arbi.agent.ArbiAgent;
import kr.ac.uos.ai.arbi.agent.ArbiAgentExecutor;
import kr.ac.uos.ai.arbi.ltm.DataSource;

public class AgentTest2 extends ArbiAgent{
	
	public void onStop(){}
	
	public String onQuery(String sender, String query){return "Ignored";}
	public void onData(String sender, String data){}
	public String onSubscribe(String sender, String subscribe){return "Ignored";}
	public void onUnsubscribe(String sender, String subID){}
	public void onNotify(String sender, String notification){}
	
	AgentTest2(){
		ArbiAgentExecutor.execute("Agent2.xml", this);
		System.out.println("agent2");
	}
	
	public void onStart(){
		DataSource dc = new DataSource();
		dc.connect("tcp://169.254.5.157:61616", "dc://testdc2");//원래는 ("tcp://169.254.5.157:61616", "dc://testdc2")였음.
		dc.assertFact("(Human_dialog \"20181010T1010\" \"오늘 오전 날씨 알려줘\")");
//		dc.assertFact("(Human_state \"20181010T1010\" \"넘어짐\")");
		
//		System.out.println(dc.notify("(Human_state \"20181010T1010\" \"넘어짐\")"));
////		System.out.println(dc.match("(Robot_position $time $position)"));
	}
	
	public String onRequest(String sender, String request){
		System.out.println("ok");
		return "null";}
	
	public static void main(String[] args) {
		new AgentTest2();
	}
}
